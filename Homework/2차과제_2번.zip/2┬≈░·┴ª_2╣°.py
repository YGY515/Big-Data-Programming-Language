# -*- coding: utf-8 -*-
"""
2차과제 1번문제 <turtle로 그림 그리기>
정보융합학부 2020204097 윤가영
"""

import turtle as tr
tr.clearscreen()

# 미로그림 삽입
def Maze():
    scr = tr.Screen()
    scr.bgpic("maze.png")
    scr.update()


# 거북이 만들기
def Turtle():
    t = tr.Turtle()
    t.shape('turtle')
    t.pensize(5)
    t.pencolor('blue')    
    return t


# 출발지점 거북이 이동
def MoveStart(t):
    t.penup()
    t.goto(-15, 380)
    t.setheading(270) # 아래보기
    t.pendown()
    t.write("출발!")


# 오른쪽으로 30도, n만큼 직진하는 함수
def Right30(n):
    t.right(30)
    t.forward(n)
    t.left(30)


# 왼쪽으로 30도, n만큼 직진하는 함수
def Left30(n):
    t.left(30)
    t.forward(n)
    t.right(30)
    
def GoRight(n):
    t.right(90)
    t.forward(n)
    t.left(90)


def GoLeft(n):
    t.left(90)
    t.forward(n)
    t.right(90)


def Moving(t):
    Right30(70)
    GoRight(50)
    Right30(50)
    GoLeft(30)
    Left30(90)
    GoLeft(40)
    Left30(50)
    GoLeft(20)
    t.setheading(90)
    Right30(50)
    GoLeft(20)
    Left30(60)
    Right30(20)
    GoRight(20)
    t.setheading(270)
    Left30(30)
    GoLeft(50)
    Left30(30)
    Right30(90)
    Left30(30)
    GoLeft(30)
    t.setheading(90)
    Right30(160)
    Left30(50)
    Right30(70)
    GoRight(90)
    t.setheading(270)
    Right30(60)
    Left30(30)
    GoLeft(50)
    for i in range (0, 2):
        Left30(30)
        Right30(65)
        
    GoRight(50)
    Right30(40)
    GoRight(30)
    t.right(180)
    Left30(30)
    GoLeft(30)
    t.setheading(270)
    Right30(40)
    GoRight(60)
    t.right(180)
    Left30(40)
    GoLeft(150)
    Left30(80)
    Right30(40)
    Left30(30)
    GoLeft(50)
    Left30(60)
    Right30(30)
    GoRight(50)
    Right30(30)
    Left30(20)
    GoLeft(180)
    t.setheading(270)
    
    for i in range (0, 2):
        Right30(60)
        Left30(60)
    GoLeft(50)
    Left30(50)
    GoRight(70)
    Right30(30)
    Left30(40)
    Right30(80)
    
    for i in range (0, 2):
        Left30(50)
        Right30(50)
    
    Left30(30)
    GoLeft(40)
    Left30(40)
    GoRight(70)
    Right30(30)
    Left30(70)
    GoLeft(180)
    t.setheading(90)
    Right30(120)
    Left30(30)
    GoLeft(30)
    t.setheading(270)
    Right30(70)
    t.setheading(90)
    Left30(40)
    Right30(110)
    GoRight(30)
    t.setheading(270)
    Left30(110)
    Right30(40)
    Left30(30)
    GoLeft(30)
    t.setheading(90)
    Right30(40)
    GoRight(75)
    t.setheading(270)
    Right30(90)
    GoRight(45)
    t.forward(40)
    t.write("도착")


# main code
Maze()
t = Turtle()
MoveStart(t)
Moving(t)

tr.done()